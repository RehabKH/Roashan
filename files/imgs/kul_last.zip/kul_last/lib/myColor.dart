

import 'package:flutter/widgets.dart';

class MyColor{

 static  final  Color customColor=Color.fromRGBO(218,165,32, 1);
}